<!DOCTYPE html>
<!-- Die Gast.php zeigt die Einträge für den Gastbenutzer ohne das er Blogeinträge
vornehmen kann. 

@version final
@copyright none

-->
<?php
session_start();
if ($_SESSION["loginOK"] != true) {
    header("Location: index.php");
} else {
    ?>

    <html>
        <head>
            <meta charset="UTF-8">
            <title>Bl0gster</title>
            <link rel="stylesheet" type="text/css" href="design.css">
        </head>
        <body>
            <h1>Your in, Gast! Welcome to the Bl0gster</h1>
            <a href="jobs/logout.php">Logout!</a>
            <?php
            include_once "db/dbcon.php";
            $stmt = $con->prepare("SELECT ideintrag, titel, eintrag, eintragdatum, email, iduser, kommentare, iduser FROM v_kommentare;")
                    or die("<b>Prepare Error: </b>" . $con->error);
            $stmt->execute();
            $stmt->bind_result($ideintrag, $titel, $eintrag, $eintragdatum, $email, $iduser, $kommentare, $iduser);
            echo '<br>';
            echo '<br>';

            while ($stmt->fetch()) {

                echo '<div style="text-align: justify">';
                echo '<h2>' . $titel . '</h2>';
                echo '<p align="center">Posted am: ' . $eintragdatum . '.</p>';
                echo '<p align="center">von: ' . $email . '</p>';
                if (file_exists("img/" . $iduser . ".jpg")) {
                    echo "<p align='center'><img src='img/$iduser.jpg' class='avatar'></p>";
                } elseif (file_exists("img/" . $iduser . ".gif")) {
                    echo "<p align='center'><img src='img/$iduser.gif' class='avatar'></p>";
                } else {
                    echo "<p align='center'><img src='img/default.jpg' class='avatar'></p>";
                }
                echo '<table style="word-break:break-all;word-wrap:break-word" border="1" align="center" width="300">';
                echo '<tr><td width ="300" valign="top">' . $eintrag . '</td></tr>';
                echo '<tr><td width ="300" align="right"><p>' . '<a href="kommentare.php?id=' . $ideintrag . '">Kommentare(' . $kommentare . ')</a>' . '</p></td></tr>';
                echo '</table>';
                echo '</div>';
            }
            ?>

        </body>

        <?php
    }
    ?>
</html>